# stx_cookbook
Altera Advanced Synthesis Cookbook 11.0

Taken from
- https://www.altera.com/literature/manual/stx_cookbook.pdf
- https://www.altera.com/literature/manual/cookbook.zip
